function id_check() {
  let chk = /[a-z]{6}/;
  let id = document.getElementById("id").value;

  if (!chk.test(id)) {
    alert("잘못된 아이디 입니다");
    document.getElementById("id").focus();
    return;
  } else document.getElementById("pwds").focus();
  pwd_check();
}

function pwd_check() {
  let pwd = document.getElementById("pwds").value;
  let chk = /[a-z0-9]{6}/;

  if (!chk.test(pwd)) {
    alert("잘못된 비밀번호 입니다");
    document.getElementById("pwds").focus();
    return;
  }
  phone_num_check();
}
function phone_num_check() {
  let phone_num = document.getElementById("phone_num").value;
  let chk = /([010{3}])-?([0-9{4}])-?([0-9]{4})/;
  alert(phone_num);
  if (!chk.test(phone_num)) {
    alert("잘못된 전화번호 입니다");
    document.getElementById("phone_num").focus();
    return;
  }
  checkcustomer();
}

function checkcustomer() {
  let id = document.getElementById("id").value;
  let pwd = document.getElementById("pwds").value;
  let phone_num = document.getElementById("phone_num").value;
  
  let name = "고객님";
  let pass = false;
  alert("고객 정보 확인중");

  const customer = [
    ["qwerty", "zxcv12", "김봉식", "01011111111"],
    ["asdfgh", "zxcv34", "김선달", "01022222222"],
    ["zxcvbn", "zxcv56", "노스트라다무스", "01033333333"],
  ];

  for (let i = 0; i < customer.length; i++) {
    if (id == customer[i][0] && pwd == customer[i][1] && phone_num == customer[i][3]) {
      pass = true;
      name = customer[i][2];
      break;
    }
  }

  if (pass == false) {
    alert("아이디 또는 비밀번호 또는 전화번호 가 맞지않습니다");
    window.open("login1.html", "_self");
  } else {
    sessionStorage.setItem("id", id);
    sessionStorage.setItem("password", pwd);
    sessionStorage.setItem("name", name);
    sessionStorage.setItem("phone", phone_num);
    window.open("login2.html");
  }

   let ctmr_id = document.getElementById("customer_id");
  let ctmr_name = document.getElementById("customer_name");

  let id_1 = sessionStorage.getItem("id");
  let name_1 = sessionStorage.getItem("name");

  ctmr_id.innerHTML = id_1;
  ctmr_name.innerHTML = name_1;
}
