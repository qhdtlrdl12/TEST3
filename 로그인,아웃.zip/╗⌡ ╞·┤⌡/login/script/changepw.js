var customer = [
  ["qwerty", "zxcv12", "김봉식"],
  ["asdfgh", "zxcv34", "김선달"],
  ["zxcvbn", "zxcv56", "노스트라다무스"],
];
function pw_change() {
  var now_pw = document.getElementById("old_pw").value;
  var new_pw = document.getElementById("new_pw").value;
  var new_pw2 = document.getElementById("new_pw2").value;
  var new_phone = document.getElementById("new_phone").value;
  var pw_data = sessionStorage.getItem("password");
  var phone_data = sessionStorage.getItem("phone");

    if (now_pw != pw_data) {
      alert("현재 비밀번호가 맞지않습니다");
      document.getElementById("old_pw").focus();
      return;
    }
  
  if (now_pw == new_pw) {
    alert("사용할수 없는 비밀번호 입니다");
    document.getElementById("new_pw").focus();
    return;
  }
  let chk = /[a-z0-9]{6}/;
  if (!chk.test(new_pw)) {
    alert("잘못된 비밀번호 입니다");
    document.getElementById("new_pw").focus();
    return;
  }
  if (new_pw != new_pw2) {
    alert("새 비밀번호가 일치하지 않습니다");
    document.getElementById("new_pw").focus();
    return;
  } else
  sessionStorage.removeItem(phone_data);
  sessionStorage.setItem("phone",new_phone);
  sessionStorage.removeItem('password');
  sessionStorage.setItem('password',new_pw);
  alert("비밀번호,전화번호 가 변경되었습니다");
  window.open("login1.html");
}
