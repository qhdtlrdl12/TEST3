function password_page(){
    alert("비밀번호를 변경하시겠습니까?");
     window.open("changepwd.html"); 

}